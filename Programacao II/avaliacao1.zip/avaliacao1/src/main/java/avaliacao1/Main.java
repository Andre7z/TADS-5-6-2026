package avaliacao1;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import avaliacao1.controller.ProdutoController;
import avaliacao1.controller.VendaController;
import avaliacao1.controller.CompraController;
import avaliacao1.model.Categoria;
import avaliacao1.model.Cliente;
import avaliacao1.model.Produto;
import avaliacao1.model.Venda;
import avaliacao1.model.ProdutoVenda;
import avaliacao1.model.Compra;
import avaliacao1.model.CompraProduto;

public class Main {
    public static void main(String[] args) {


    }
}